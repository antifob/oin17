var structlws__pollargs =
[
    [ "events", "structlws__pollargs.html#a00bbffea9f55de342783e32d71ce1de6", null ],
    [ "fd", "structlws__pollargs.html#af14a48ef4e78128aef9a76902b104a81", null ],
    [ "prev_events", "structlws__pollargs.html#a437fec0de5cf264371e1ab5a401e86d8", null ]
];