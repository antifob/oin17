var structlws__gs__event__args =
[
    [ "email", "structlws__gs__event__args.html#acd17e4f9f91f7f9a8f0fbf0744a3a463", null ],
    [ "event", "structlws__gs__event__args.html#a477274f8ca22ba7411b9285b9dc8dd06", null ],
    [ "username", "structlws__gs__event__args.html#a2bec693d8a43730d487004a44326178b", null ]
];