var globals_dup =
[
    [ "e", "globals.html", null ],
    [ "l", "globals_l.html", null ]
];