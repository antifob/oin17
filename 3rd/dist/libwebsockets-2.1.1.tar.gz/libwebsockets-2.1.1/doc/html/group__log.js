var group__log =
[
    [ "lws_set_log_level", "group__log.html#ga244647f9e1bf0097ccdde66d74f41e26", null ],
    [ "lwsl_emit_syslog", "group__log.html#gab7c0fc936cc9f1eb58e2bb234c15147c", null ],
    [ "lwsl_hexdump", "group__log.html#ga898b1f03872ad019f507d4e35bbefa90", null ],
    [ "lwsl_timestamp", "group__log.html#ga42e39775c6b69b7251bdbf5a2cdd5dcd", null ]
];