var structlws__extension =
[
    [ "callback", "structlws__extension.html#afa21f3b3c8c2c9212a276c52b680c3af", null ],
    [ "client_offer", "structlws__extension.html#a36b06c213aedb02bf9a402651751855b", null ],
    [ "name", "structlws__extension.html#a1e5018c883d85176f5c2152176843f9e", null ]
];