var group__wsclose =
[
    [ "lws_close_status", "group__wsclose.html#gae399c571df32ba532c0ca67da9284985", [
      [ "LWS_CLOSE_STATUS_NORMAL", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985a3ffa38d5081b85fb739e02a747ccf2c4", null ],
      [ "LWS_CLOSE_STATUS_GOINGAWAY", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985a9737a68759e739856b150ff9dfa30218", null ],
      [ "LWS_CLOSE_STATUS_PROTOCOL_ERR", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985a1bb501d212fa4d57053db681b1dfab98", null ],
      [ "LWS_CLOSE_STATUS_UNACCEPTABLE_OPCODE", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985a462c99b05459df700919cfd3f53c8276", null ],
      [ "LWS_CLOSE_STATUS_RESERVED", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985af90cb98d983ad3d4c79df9b6f3d4a4d2", null ],
      [ "LWS_CLOSE_STATUS_NO_STATUS", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985a4b8a3b7ce6f731e5248e4b0fb64a5044", null ],
      [ "LWS_CLOSE_STATUS_ABNORMAL_CLOSE", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985a68b3d34bebd88547dcfa5cadba0acd6c", null ],
      [ "LWS_CLOSE_STATUS_INVALID_PAYLOAD", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985a7aef2da0062da606eeb35aaca5cf9050", null ],
      [ "LWS_CLOSE_STATUS_POLICY_VIOLATION", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985ad09e68295eabdddcba4e332fbea70ae5", null ],
      [ "LWS_CLOSE_STATUS_MESSAGE_TOO_LARGE", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985a2e1f0113494a58e762eed3d22e7080d8", null ],
      [ "LWS_CLOSE_STATUS_EXTENSION_REQUIRED", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985ac6a161822783ee873be1c66f48d14e0e", null ],
      [ "LWS_CLOSE_STATUS_UNEXPECTED_CONDITION", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985ad0869604d79e13700ae5d196a431b350", null ],
      [ "LWS_CLOSE_STATUS_TLS_FAILURE", "group__wsclose.html#ggae399c571df32ba532c0ca67da9284985ad2b477a91c8445bf34ecd43977f9b390", null ]
    ] ],
    [ "lws_close_reason", "group__wsclose.html#gaa1c863415d1783cd8de7938aa6efa262", null ]
];